package main

import (
	"net"
)

func reverse(data []byte) []byte {
	for i, j := 0, len(data)-1; i < j; i, j = i+1, j-1 {
		data[i], data[j] = data[j], data[i]
	}
	return data
}

func handleConnection(localConn net.Conn) {
	defer localConn.Close()

	serverConn, _ := net.Dial("tcp", ":5679")
	defer serverConn.Close()

	go func() {
		for {
			buf := make([]byte, 1024*1024)
			n, _ := localConn.Read(buf)
			encryptedData := reverse(buf[:n])
			serverConn.Write(encryptedData)
		}
	}()

	for {
		buf := make([]byte, 1024*1024)
		n, _ := serverConn.Read(buf)
		deencryptedData := reverse(buf[:n])
		localConn.Write(deencryptedData)
	}
}

func main() {
	listener, _ := net.Listen("tcp", "127.0.0.1:5678")
	defer listener.Close()

	for {
		conn, _ := listener.Accept()
		go handleConnection(conn)
	}
}
