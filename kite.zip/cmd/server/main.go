package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"strconv"
)

func reverse(data []byte) []byte {
	for i, j := 0, len(data)-1; i < j; i, j = i+1, j-1 {
		data[i], data[j] = data[j], data[i]
	}
	return data
}

func handleSocks5Handshake(conn net.Conn) string {
	buf := make([]byte, 2048)
	conn.Read(buf)

	conn.Write(reverse([]byte{0x05, 0x00}))

	n, _ := conn.Read(buf)
	buf = reverse(buf[:n])

	var addr string
	switch buf[3] {
	case 0x01: // IPv4 地址
		ip := buf[:4]
		port := buf[4:]
		addr = net.IP(ip).String() + ":" + strconv.Itoa(int(binary.BigEndian.Uint16(port)))
	case 0x03: // 域名地址
		addrLen := int(buf[4])
		domain := buf[5 : 5+addrLen]
		port := buf[5+addrLen:]
		addr = string(domain) + ":" + strconv.Itoa(int(binary.BigEndian.Uint16(port)))
	}

	successResponse := reverse([]byte{0x05, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00})
	conn.Write(successResponse)

	return addr
}

func main() {
	listener, _ := net.Listen("tcp", ":5679")
	defer listener.Close()

	for {
		conn, _ := listener.Accept()
		go func(conn net.Conn) {
			defer conn.Close()
			targetAddr := handleSocks5Handshake(conn)
			fmt.Println(targetAddr)

			serverConn, _ := net.Dial("tcp", targetAddr)
			defer serverConn.Close()
			go func() {
				for {
					buf := make([]byte, 1024*1024)
					n, _ := conn.Read(buf)
					encryptedData := reverse(buf[:n])
					serverConn.Write(encryptedData)
				}
			}()

			for {
				buf := make([]byte, 1024*1024)
				n, _ := serverConn.Read(buf)
				deencryptedData := reverse(buf[:n])
				conn.Write(deencryptedData)
			}
		}(conn)
	}
}
