package kite

type Cipher interface {
	Encrypt([]byte) []byte
	Decrypt([]byte) []byte
}

type ReverseCipher struct{}

func (r ReverseCipher) Encrypt(data []byte) []byte {
	for i, j := 0, len(data)-1; i < j; i, j = i+1, j-1 {
		data[i], data[j] = data[j], data[i]
	}
	return data
}

func (r ReverseCipher) Decrypt(data []byte) []byte {
	// 由于加密和解密是同样的操作，这里直接调用 Encrypt
	return r.Encrypt(data)
}
