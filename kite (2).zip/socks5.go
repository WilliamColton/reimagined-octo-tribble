package kite

import (
	"encoding/binary"
	"fmt"
	"net"
	"strconv"
)

func HandleSocks5Handshake(conn net.Conn, cipher Cipher) (string, error) {
	buf := make([]byte, 32*1024)

	// 读取客户端的握手请求
	n, err := conn.Read(buf)
	if err != nil {
		return "", fmt.Errorf("failed to read handshake request: %v", err)
	}

	// 发送握手响应
	_, err = conn.Write(cipher.Encrypt([]byte{0x05, 0x00}))
	if err != nil {
		return "", fmt.Errorf("failed to write handshake response: %v", err)
	}

	// 读取客户端发送的请求
	n, err = conn.Read(buf)
	if err != nil {
		return "", fmt.Errorf("failed to read client request: %v", err)
	}
	buf = cipher.Decrypt(buf[:n])

	// 解析目标地址
	var addr string
	switch buf[3] {
	case 0x01: // IPv4 地址
		if len(buf) < 10 {
			return "", fmt.Errorf("invalid IPv4 address format")
		}
		ip := buf[4:8]
		port := buf[8:10]
		addr = net.IP(ip).String() + ":" + strconv.Itoa(int(binary.BigEndian.Uint16(port)))
	case 0x03: // 域名地址
		if len(buf) < 5 {
			return "", fmt.Errorf("invalid domain name format")
		}
		addrLen := int(buf[4])
		if len(buf) < 5+addrLen+2 {
			return "", fmt.Errorf("invalid domain name length")
		}
		domain := buf[5 : 5+addrLen]
		port := buf[5+addrLen : 5+addrLen+2]
		addr = string(domain) + ":" + strconv.Itoa(int(binary.BigEndian.Uint16(port)))
	default:
		return "", fmt.Errorf("unsupported address type: %v", buf[3])
	}

	conn.Write(cipher.Encrypt([]byte{0x05, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}))

	return addr, nil
}
