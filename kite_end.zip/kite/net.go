package kite

import (
	"errors"
	"fmt"
	"io"
	"net"
)

// ExchangeData 在 srcConn 和 dstConn 之间交换数据，并使用 Cipher 进行加密和解密。
func ExchangeData(srcConn, dstConn net.Conn, cipher Cipher) error {
	go CopyData(srcConn, dstConn, cipher)

	CopyData(dstConn, srcConn, cipher)

	return nil
}

func CopyData(srcConn, dstConn net.Conn, cipher Cipher) (err error) {
	buf := make([]byte, 32*1024)
	for {
		nr, er := srcConn.Read(buf)
		if nr > 0 {
			nw, ew := dstConn.Write(cipher.Encrypt(buf[0:nr]))
			//runtime.GC()
			//fmt.Println("内容：", cipher.Encrypt(buf[0:nr]))
			//time.Sleep(1 * time.Nanosecond)
			if nw < 0 || nr < nw {
				nw = 0
				if ew == nil {
					ew = errors.New("short write")
				}
			}

			if ew != nil {
				_ = ew
				break
			}
			if nr != nw {
				_ = io.ErrShortWrite
				break
			}
		}
		if er != nil {
			if er != io.EOF {
				_ = er
			}
			break
		}
	}
	fmt.Println("CopyData err:", err)
	return err
}
