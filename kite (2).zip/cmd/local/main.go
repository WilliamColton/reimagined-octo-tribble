package main

import (
	"fmt"
	"kite"
	"net"
	"time"
)

func handleConnection(localConn net.Conn) {
	defer localConn.Close()

	serverConn, _ := net.Dial("tcp", ":5679")
	defer serverConn.Close()

	// 设置超时时间
	localConn.SetDeadline(time.Now().Add(5 * time.Minute))
	serverConn.SetDeadline(time.Now().Add(5 * time.Minute))

	// 使用 exchangeData 函数来处理数据交换
	cipher := kite.ReverseCipher{}
	if err := kite.ExchangeData(localConn, serverConn, cipher); err != nil {
		fmt.Println("Proxy error:", err)
	}
}
func main() {
	listener, _ := net.Listen("tcp", "127.0.0.1:5678")
	defer listener.Close()

	for {
		conn, _ := listener.Accept()

		go handleConnection(conn)
	}
}
