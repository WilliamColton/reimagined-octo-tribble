package main

import (
	"fmt"
	"kite"
	"net"
)

func handleConnection(localConn net.Conn) {
	defer localConn.Close()

	serverConn, _ := net.Dial("tcp", "154.204.56.133:5679")
	defer serverConn.Close()

	// 使用 exchangeData 函数来处理数据交换
	cipher := kite.ReverseCipher{}
	if err := kite.ExchangeData(localConn, serverConn, cipher); err != nil {
		fmt.Println("Proxy error:", err)
	}
}
func main() {
	fmt.Println("start")
	listener, _ := net.Listen("tcp", ":5678")
	defer listener.Close()

	for {
		conn, _ := listener.Accept()

		go handleConnection(conn)
	}
}
