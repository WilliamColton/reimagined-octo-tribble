package kite

type Cipher interface {
	Encrypt([]byte) []byte
	Decrypt([]byte) []byte
}

type ReverseCipher struct{}

func (r ReverseCipher) Encrypt(data []byte) []byte {
	for i := range data {
		data[i] ^= 0x2
	}
	return data
}

func (r ReverseCipher) Decrypt(data []byte) []byte {
	// 由于加密和解密是同样的操作，这里直接调用 Encrypt
	return r.Encrypt(data)
}
