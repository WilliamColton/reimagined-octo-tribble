package main

import (
	"fmt"
	"kite"
	"net"
)

// 使用 exchangeData 来简化数据交换逻辑
func handleConnection(clientConn net.Conn, cipher kite.Cipher) {
	defer clientConn.Close()
	// 处理SOCKS5握手并获取目标地址
	targetAddr, _ := kite.HandleSocks5Handshake(clientConn, cipher)
	fmt.Println("Connecting to", targetAddr)

	// 连接到目标服务器
	serverConn, _ := net.Dial("tcp", targetAddr)
	defer serverConn.Close()

	fmt.Println("server开始数据交换")
	// 进行数据交换，使用加密解密
	if err := kite.ExchangeData(clientConn, serverConn, cipher); err != nil {
		fmt.Println("Proxy error:", err)
	}
}

func main() {
	fmt.Println("start")
	cipher := kite.ReverseCipher{}
	listener, _ := net.Listen("tcp", ":5679")
	defer listener.Close()
	for {
		conn, _ := listener.Accept()

		go handleConnection(conn, cipher)
	}
}
